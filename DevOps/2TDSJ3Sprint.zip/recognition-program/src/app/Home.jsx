import React, { useState, useEffect } from "react";
import {
  Container,
  Paper,
  Grid,
  TextField,
  ButtonGroup,
  Button,
  Typography,
  makeStyles,
  Link,
} from "@material-ui/core";

import { initializeApp } from "firebase/app";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  updateProfile,
  deleteUser,
  signOut,
} from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyBjNnLlbkcJK4niQk04o-45qHVyOGmA9ZM",
  authDomain: "fiap-challenge3.firebaseapp.com",
  projectId: "fiap-challenge3",
  storageBucket: "fiap-challenge3.appspot.com",
  messagingSenderId: "747537020489",
  appId: "1:747537020489:web:7a640575756faf769b3198",
  measurementId: "G-29B9T8STWB",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const useStyles = makeStyles({
  container: {
    height: "100%",
    display: "grid",
    placeItems: "center",
  },
  paper: {
    position: "relative",
    width: "100%",
    margin: "0 1rem",
    padding: "3rem",
    maxWidth: 600,
    background: "#1976d2",
    color: "#FFFFFF",
  },
  link: {
    position: "absolute",
    bottom: "-60px",
    left: "50%",
    transform: "translateX(-50%)",
    color: "#000",
  },
});

export default function Home() {
  const classes = useStyles();

  const [values, setValues] = useState({
    email: "",
    pass: "",
    name: "",
    phone: "",
  });

  const handleChange = (e, field) => {
    setValues({ ...values, [field]: e.target.value });
  };

  const auth = getAuth();

  useEffect(() => {
    onAuthStateChanged(auth, (user) => {
      if (user) {
        setValues({ email: "", name: "", pass: "" });
        setUserLogged(user);
        setStatus("logged");
      } else {
        setUserLogged({});
        setStatus("signIn");
      }
    });
  }, [auth.currentUser]);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (status === "signIn") {
      signInWithEmailAndPassword(auth, values.email, values.pass)
        .then((userCredential) => {
          // Signed in
          console.log("SIGNED");
        })
        .catch((error) => {
          const errorCode = error.code;
          const errorMessage = error.message;
          console.log(errorCode, errorMessage);
        });
    } else if (status === "signUp") {
      createUserWithEmailAndPassword(auth, values.email, values.pass)
        .then((userCredential) => {
          // Signed in
          updateProfile(auth.currentUser, {
            displayName: values.name,
          })
            .then(() => {
              console.log("CREATED");
            })
            .catch((e) => {
              console.log(e);
            });
        })
        .catch((error) => {
          const errorCode = error.code;
          const errorMessage = error.message;
          console.log(errorCode, errorMessage);
        });
    } else if (status === "edit") {
      updateProfile(auth.currentUser, {
        displayName: values.name,
      })
        .then(() => {
          console.log("UPDATED");
          setUserLogged({ ...userLogged, displayName: values.name });
          setStatus("logged");
        })
        .catch((e) => {
          console.log(e);
        });
    }
  };

  const signUp = new Date().toLocaleDateString("pt-br");

  const [status, setStatus] = useState("signIn");

  const changeStatus = (status) => {
    setValues({
      name: "",
      email: "",
      pass: "",
    });
    setStatus(status);
  };

  const [userLogged, setUserLogged] = useState({});

  const handleUpdate = () => {
    setStatus("edit");
  };

  const handleLogOut = () => {
    signOut(auth)
      .then(() => {
        console.log("SIGNED OUT");
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const handleDelete = () => {
    deleteUser(auth.currentUser)
      .then(() => {
        console.log("DELETED");
      })
      .catch((e) => {
        console.log(e);
      });
  };

  return (
    <Container className={classes.container} maxWidth="lg">
      <Paper className={classes.paper} elevation={5}>
        {status === "signIn" ? (
          <form onSubmit={handleSubmit} autoComplete="off">
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Typography variant="h4" component="h1">
                  Entrar no Recognition Program
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  variant="filled"
                  label="E-mail"
                  type="email"
                  value={values.email}
                  onChange={(e) => handleChange(e, "email")}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  variant="filled"
                  label="Senha"
                  type="current-password"
                  value={values.pass}
                  onChange={(e) => handleChange(e, "pass")}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <Button type="submit" variant="contained">
                  Entrar
                </Button>
              </Grid>
            </Grid>
          </form>
        ) : status === "signUp" ? (
          <form onSubmit={handleSubmit} autoComplete="off">
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Typography variant="h4" component="h1">
                  Registrar no Recognition Program
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  variant="filled"
                  label="Nome completo"
                  type="name"
                  value={values.name}
                  onChange={(e) => handleChange(e, "name")}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  variant="filled"
                  label="E-mail"
                  type="email"
                  value={values.email}
                  onChange={(e) => handleChange(e, "email")}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  variant="filled"
                  label="Senha"
                  type="new-password"
                  value={values.pass}
                  onChange={(e) => handleChange(e, "pass")}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <Button type="submit" variant="contained">
                  Registrar
                </Button>
              </Grid>
            </Grid>
          </form>
        ) : status === "logged" ? (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Typography variant="h4" component="h1">
                Bem-vindo ao Recognition Program
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle1">
                Nome completo: {userLogged.displayName}
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle1">
                E-mail: {userLogged.email}
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle1">
                Data de cadastro: {signUp}
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <ButtonGroup variant="contained">
                <Button onClick={handleLogOut}>Sair</Button>
                <Button onClick={handleUpdate}>Alterar conta</Button>
                <Button onClick={handleDelete}>Deletar conta</Button>
              </ButtonGroup>
            </Grid>
          </Grid>
        ) : status === "edit" ? (
          <form onSubmit={handleSubmit} autoComplete="off">
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Typography variant="h4" component="h1">
                  Editar conta
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  variant="filled"
                  label="Nome completo"
                  type="name"
                  value={values.name}
                  onChange={(e) => handleChange(e, "name")}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <Button type="submit" variant="contained">
                  Editar
                </Button>
              </Grid>
            </Grid>
          </form>
        ) : null}
        {status !== "logged" && status !== "edit" ? (
          <Typography className={classes.link} variant="h6">
            ou{" "}
            <Link
              href="#"
              onClick={() =>
                changeStatus(status === "signIn" ? "signUp" : "signIn")
              }
            >
              {status === "signIn" ? "registre-se" : "entrar"}
            </Link>
          </Typography>
        ) : null}
      </Paper>
    </Container>
  );
}
