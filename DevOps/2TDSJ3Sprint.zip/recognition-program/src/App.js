import Home from './app/Home';

function App() {
  return (
    <Home />
  );
}

export default App;
